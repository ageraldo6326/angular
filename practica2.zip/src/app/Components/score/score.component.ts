import { Component } from '@angular/core';

@Component({
  selector: 'app-score',
  imports: [],
  templateUrl: './score.component.html',
  styleUrl: './score.component.css'
})
export class ScoreComponent {

score:number = 0;

scoreGenerator() {
  this.score = Math.round(Math.random() * 100)
}
ngOnInit() {
  this.scoreGenerator()
}

}

import { CommonModule, DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { ListaFrutasComponent } from "./Components/lista-frutas/lista-frutas.component";
import { ListaUsuarioComponent } from './Components/lista-usuario/lista-usuario.component';
import { ScoreComponent } from "./Components/score/score.component";
import { FormsModule } from '@angular/forms';
import { MessageComponent } from "./Components/message/message.component";
import { ColorBoxComponent } from "./Components/color-box/color-box.component";
import { AlertButtonComponent } from "./Components/alert-button/alert-button.component";
import { CounterComponent } from "./Components/counter/counter.component";
import { UsuarioComponent } from "./Components/usuario/usuario.component";
import { PerritosService } from './services/perritos.service';
import { GuarderiaPerritosComponent } from "./Components/guarderia-perritos/guarderia-perritos.component";
import { MenuComponent } from "./Components/menu/menu.component";
import { BienvenidoComponent } from "./Components/bienvenido/bienvenido.component";
import { InterporlacionComponent } from "./Components/interporlacion/interporlacion.component";
import { MensajeBotonComponent } from "./Components/mensaje-boton/mensaje-boton.component";
import { MensajeHijoPadreComponent } from "./Components/mensaje-hijo-padre/mensaje-hijo-padre.component";
import { MensajePadreHijoComponent } from "./Components/mensaje-padre-hijo/mensaje-padre-hijo.component";
import { PipeComponent } from "./Components/pipe/pipe.component";



@Component({
  selector: 'app-root',
  imports: [RouterOutlet, DatePipe, ListaFrutasComponent, ScoreComponent, ListaUsuarioComponent, CommonModule, FormsModule, MessageComponent, ColorBoxComponent, AlertButtonComponent, CounterComponent, UsuarioComponent, GuarderiaPerritosComponent, MenuComponent, BienvenidoComponent, InterporlacionComponent, MensajeBotonComponent, MensajeHijoPadreComponent, MensajePadreHijoComponent, PipeComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'proyecto';
  welcomeMessage = 'Bienvenido a mi aplicación Angular';
  condicion: boolean = false;


  constructor (private perritoService: PerritosService) {}
  

  cambiar() {
    this.title = "Titulo cambiado"
  }




}

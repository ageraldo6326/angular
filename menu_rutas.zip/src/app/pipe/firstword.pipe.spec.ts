import { FirstwordPipe } from './firstword.pipe';

describe('FirstwordPipe', () => {
  it('create an instance', () => {
    const pipe = new FirstwordPipe();
    expect(pipe).toBeTruthy();
  });
});

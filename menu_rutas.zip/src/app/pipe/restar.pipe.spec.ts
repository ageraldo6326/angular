import { RestarPipe } from './restar.pipe';

describe('RestarPipe', () => {
  it('create an instance', () => {
    const pipe = new RestarPipe();
    expect(pipe).toBeTruthy();
  });
});

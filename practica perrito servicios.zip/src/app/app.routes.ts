import { Routes } from '@angular/router';
import { GuarderiaPerritosComponent } from './Components/guarderia-perritos/guarderia-perritos.component';
import { ColorBoxComponent } from './Components/color-box/color-box.component';
import { AlertButtonComponent } from './Components/alert-button/alert-button.component';
import { CounterComponent } from './Components/counter/counter.component';
import { ListaFrutasComponent } from './Components/lista-frutas/lista-frutas.component';
import { MessageComponent } from './Components/message/message.component';
import { ScoreComponent } from './Components/score/score.component';
import { UsuarioComponent } from './Components/usuario/usuario.component';

export const routes: Routes = [
  {path: 'usuarios', component: UsuarioComponent},
  {path: 'colorbox', component: ColorBoxComponent},
  {path: 'perritos', component: GuarderiaPerritosComponent},
  {path: 'alertbutton', component: AlertButtonComponent},
  {path: 'counter', component: CounterComponent},
  {path: 'listafrutas', component: ListaFrutasComponent},
  {path: 'listausuarios', component: ListaFrutasComponent},
  {path: 'message', component: MessageComponent},
  {path: 'score', component: ScoreComponent},
];

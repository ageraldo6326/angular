import { ReversetextPipe } from './reversetext.pipe';

describe('ReversetextPipe', () => {
  it('create an instance', () => {
    const pipe = new ReversetextPipe();
    expect(pipe).toBeTruthy();
  });
});
